<?php
$color_text_color = array(
    0 => 'body',
    1 => ' p',
    2 => ' .widget.widget_search input[type="text"]',
    3 => '#content-container .fw-tabs-container .fw-tabs ul li a',
    4 => ' .fw-accordion .fw-accordion-title',
    5 => ' #featuredbox.has-search form input',
    6 => ' #content-container div.item-list-tabs ul li a',
    7 => ' #content-container div.item-list-tabs-wiki ul li a',
    8 => ' #content-container div.item-list-tabs-project ul li a',
    9 => ' table.profile-fields td.label',
    10 => ' #item-header.no-featured',
    11 => ' #user-sidebar nav ul li a',
    12 => ' #content-container .eventon_fc_days .evo_fc_day:hover',
    13 => ' .wcContainer *',
    14 => 'legend',
    15 => ' a#can-scroll',
    16 => '#navbar #nav-user a#user-thumb',
    17 => ' #featuredbox .pagetitle #directory-search form #s',
    18 => ' .woffice-notifications-item a',
    19 => ' #featuredbox.has-search.search-buddypress form i.fa-spin',
    20 => '#woffice-project-todo .woffice-project-filters li a.is-on'
);
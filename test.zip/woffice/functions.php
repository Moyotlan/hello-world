<?php 
/**
 * Theme Includes
 */
require_once get_template_directory() .'/inc/init.php';
